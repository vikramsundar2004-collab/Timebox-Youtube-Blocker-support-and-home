const STORAGE_KEY = "timeboxYouTubeBlockerState";

function isBlockedPage() {
  return location.href === chrome.runtime.getURL("blocked.html");
}

function redirectIfBlocked(state) {
  if (isBlockedPage()) {
    return;
  }

  const breakActive = state?.breakActive && Number(state.breakUntil) > Date.now();

  if (breakActive) {
    return;
  }

  location.replace(chrome.runtime.getURL("blocked.html"));
}

chrome.storage.local.get(STORAGE_KEY, (stored) => {
  redirectIfBlocked(stored[STORAGE_KEY]);
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !changes[STORAGE_KEY]) {
    return;
  }

  redirectIfBlocked(changes[STORAGE_KEY].newValue);
});
