const policyText = document.querySelector("#policyText");
const closeTabsInput = document.querySelector("#closeTabsInput");
const saveButton = document.querySelector("#saveButton");
const breakButton = document.querySelector("#breakButton");
const endBreakButton = document.querySelector("#endBreakButton");
const messageText = document.querySelector("#messageText");

let currentState = null;

function sendMessage(type, payload = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, payload }, (response) => {
      const runtimeError = chrome.runtime.lastError;

      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }

      if (!response?.ok) {
        reject(new Error(response?.error || "The extension did not respond."));
        return;
      }

      resolve(response.state);
    });
  });
}

function formatTime(time) {
  return new Date(time).toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit"
  });
}

function renderState(state) {
  currentState = state;
  closeTabsInput.checked = state.closeExistingTabs !== false;

  if (state.breakActive) {
    policyText.textContent = `Break active until ${formatTime(state.breakUntil)}. ${state.breaksRemaining} breaks left after this one.`;
    breakButton.disabled = true;
    endBreakButton.disabled = false;
    return;
  }

  policyText.textContent = state.dailyLimitReached
    ? "Blocking protocol is active. You used all 3 breaks today."
    : `${state.breaksRemaining} of ${state.dailyBreakLimit} YouTube breaks left today. Each break lasts ${state.breakDurationMinutes} minutes.`;
  breakButton.disabled = state.dailyLimitReached;
  endBreakButton.disabled = true;
}

async function loadOptions() {
  try {
    const state = await sendMessage("GET_STATE");
    renderState(state);
  } catch (error) {
    messageText.textContent = error.message;
  }
}

async function startBreak() {
  try {
    messageText.textContent = "";
    breakButton.disabled = true;
    const state = await sendMessage("START_BREAK");
    renderState(state);
    messageText.textContent = `Break started. YouTube is unlocked until ${formatTime(state.breakUntil)}.`;
  } catch (error) {
    messageText.textContent = error.message;
  } finally {
    breakButton.disabled = Boolean(currentState?.dailyLimitReached || currentState?.breakActive);
  }
}

async function endBreak() {
  try {
    messageText.textContent = "";
    endBreakButton.disabled = true;
    const state = await sendMessage("END_BREAK");
    renderState(state);
    messageText.textContent = "Break ended. YouTube is blocked again.";
  } catch (error) {
    messageText.textContent = error.message;
  } finally {
    endBreakButton.disabled = !currentState?.breakActive;
  }
}

async function saveOptions() {
  try {
    messageText.textContent = "";
    saveButton.disabled = true;
    const state = await sendMessage("UPDATE_SETTINGS", {
      closeExistingTabs: closeTabsInput.checked
    });
    renderState(state);
    messageText.textContent = "Saved.";
  } catch (error) {
    messageText.textContent = error.message;
  } finally {
    saveButton.disabled = false;
  }
}

saveButton.addEventListener("click", saveOptions);
breakButton.addEventListener("click", startBreak);
endBreakButton.addEventListener("click", endBreak);

void loadOptions();
