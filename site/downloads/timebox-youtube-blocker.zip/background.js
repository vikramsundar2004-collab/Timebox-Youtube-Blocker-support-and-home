const STORAGE_KEY = "timeboxYouTubeBlockerState";
const BREAK_END_ALARM = "timebox-youtube-break-end";
const TICK_ALARM = "timebox-youtube-break-tick";

const BREAK_DURATION_MINUTES = 20;
const DAILY_BREAK_LIMIT = 3;

const RULE_IDS = Object.freeze({
  youtube: 9101,
  youtuBe: 9102,
  youtubeNoCookie: 9103,
  googleVideo: 9104
});

const RULE_ID_LIST = Object.values(RULE_IDS);

const DEFAULT_STATE = Object.freeze({
  breakActive: false,
  breakStartedAt: 0,
  breakUntil: 0,
  breakDate: "",
  breaksUsed: 0,
  breakDurationMinutes: BREAK_DURATION_MINUTES,
  dailyBreakLimit: DAILY_BREAK_LIMIT,
  closeExistingTabs: true,
  lastBreakEndedAt: 0,
  lastBreakEndReason: "",
  totalBreaksUsed: 0
});

const YOUTUBE_TAB_PATTERNS = [
  "*://youtube.com/*",
  "*://*.youtube.com/*",
  "*://youtu.be/*",
  "*://*.youtu.be/*",
  "*://youtube-nocookie.com/*",
  "*://*.youtube-nocookie.com/*",
  "*://googlevideo.com/*",
  "*://*.googlevideo.com/*"
];

function blockedPageUrl() {
  return chrome.runtime.getURL("blocked.html");
}

function localDateKey(time = Date.now()) {
  const date = new Date(time);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function nextLocalMidnight(time = Date.now()) {
  const date = new Date(time);
  date.setHours(24, 0, 0, 0);
  return date.getTime();
}

function normalizeState(rawState = {}, time = Date.now()) {
  const today = localDateKey(time);
  const state = {
    ...DEFAULT_STATE,
    ...rawState,
    breakDurationMinutes: BREAK_DURATION_MINUTES,
    dailyBreakLimit: DAILY_BREAK_LIMIT
  };

  if (!state.breakDate) {
    state.breakDate = today;
  }

  if (state.breakActive && Number(state.breakUntil) <= time) {
    state.breakActive = false;
    state.breakStartedAt = 0;
    state.breakUntil = 0;
    state.lastBreakEndedAt = time;
    state.lastBreakEndReason = "expired";
  }

  if (!state.breakActive && state.breakDate !== today) {
    state.breakDate = today;
    state.breaksUsed = 0;
    state.lastBreakEndReason = "";
  }

  state.breaksUsed = Math.max(0, Math.min(DAILY_BREAK_LIMIT, Number(state.breaksUsed) || 0));
  state.totalBreaksUsed = Math.max(0, Number(state.totalBreaksUsed) || 0);
  state.closeExistingTabs = state.closeExistingTabs !== false;

  return state;
}

function isBreakActive(state, time = Date.now()) {
  return Boolean(state.breakActive && Number(state.breakUntil) > time);
}

function toPublicState(state, time = Date.now()) {
  const activeBreak = isBreakActive(state, time);
  const breaksRemaining = Math.max(0, DAILY_BREAK_LIMIT - state.breaksUsed);

  return {
    ...state,
    breakActive: activeBreak,
    isBlocked: !activeBreak,
    breaksRemaining,
    dailyLimitReached: breaksRemaining <= 0 && !activeBreak,
    nextResetAt: nextLocalMidnight(time)
  };
}

async function getState() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  return normalizeState(stored[STORAGE_KEY] || {});
}

async function saveState(state) {
  await chrome.storage.local.set({ [STORAGE_KEY]: normalizeState(state) });
}

function buildDynamicRules() {
  const redirectToBlockedPage = {
    type: "redirect",
    redirect: {
      extensionPath: "/blocked.html"
    }
  };

  return [
    {
      id: RULE_IDS.youtube,
      priority: 1,
      action: redirectToBlockedPage,
      condition: {
        urlFilter: "||youtube.com/",
        resourceTypes: ["main_frame", "sub_frame"]
      }
    },
    {
      id: RULE_IDS.youtuBe,
      priority: 1,
      action: redirectToBlockedPage,
      condition: {
        urlFilter: "||youtu.be/",
        resourceTypes: ["main_frame", "sub_frame"]
      }
    },
    {
      id: RULE_IDS.youtubeNoCookie,
      priority: 1,
      action: redirectToBlockedPage,
      condition: {
        urlFilter: "||youtube-nocookie.com/",
        resourceTypes: ["main_frame", "sub_frame"]
      }
    },
    {
      id: RULE_IDS.googleVideo,
      priority: 1,
      action: {
        type: "block"
      },
      condition: {
        urlFilter: "||googlevideo.com/",
        resourceTypes: ["main_frame", "sub_frame", "media", "xmlhttprequest"]
      }
    }
  ];
}

async function enableBlockingRules() {
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: RULE_ID_LIST,
    addRules: buildDynamicRules()
  });
}

async function disableBlockingRules() {
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: RULE_ID_LIST
  });
}

async function scheduleAlarms(state) {
  await chrome.alarms.create(TICK_ALARM, { periodInMinutes: 1 });

  if (isBreakActive(state)) {
    await chrome.alarms.create(BREAK_END_ALARM, { when: state.breakUntil });
    return;
  }

  await chrome.alarms.clear(BREAK_END_ALARM);
}

function isYoutubeLikeUrl(url) {
  try {
    const hostname = new URL(url).hostname.toLowerCase();

    return (
      hostname === "youtube.com" ||
      hostname.endsWith(".youtube.com") ||
      hostname === "youtu.be" ||
      hostname.endsWith(".youtu.be") ||
      hostname === "youtube-nocookie.com" ||
      hostname.endsWith(".youtube-nocookie.com") ||
      hostname === "googlevideo.com" ||
      hostname.endsWith(".googlevideo.com")
    );
  } catch {
    return false;
  }
}

async function redirectExistingYouTubeTabs() {
  const tabs = await chrome.tabs.query({ url: YOUTUBE_TAB_PATTERNS });
  await Promise.all(
    tabs.map(async (tab) => {
      if (!tab.id || tab.url === blockedPageUrl()) {
        return;
      }

      try {
        await chrome.tabs.update(tab.id, { url: blockedPageUrl() });
      } catch {
        // Protected browser pages and discarded tabs can reject updates.
      }
    })
  );
}

function formatBreakBadge(breakUntil) {
  const remainingMs = Math.max(0, breakUntil - Date.now());
  const remainingMinutes = Math.ceil(remainingMs / 60000);

  if (remainingMinutes <= 0) {
    return "";
  }

  if (remainingMinutes >= 60) {
    return `${Math.ceil(remainingMinutes / 60)}h`;
  }

  return `${remainingMinutes}m`;
}

async function updateBadge(state) {
  if (isBreakActive(state)) {
    await chrome.action.setBadgeBackgroundColor({ color: "#1b7f3a" });
    await chrome.action.setBadgeText({ text: formatBreakBadge(state.breakUntil) });
    return;
  }

  await chrome.action.setBadgeBackgroundColor({ color: "#b3261e" });
  await chrome.action.setBadgeText({ text: String(Math.max(0, DAILY_BREAK_LIMIT - state.breaksUsed)) });
}

async function startBreak() {
  const state = await getState();
  const now = Date.now();

  if (isBreakActive(state, now)) {
    throw new Error("A break is already running. You cannot add more time to it.");
  }

  if (state.breaksUsed >= DAILY_BREAK_LIMIT) {
    await syncBlockState({ redirectTabs: true });
    throw new Error("All 3 YouTube breaks are used for today. Blocking protocol is active until tomorrow.");
  }

  const nextState = normalizeState({
    ...state,
    breakActive: true,
    breakStartedAt: now,
    breakUntil: now + BREAK_DURATION_MINUTES * 60000,
    breakDate: localDateKey(now),
    breaksUsed: state.breaksUsed + 1,
    totalBreaksUsed: state.totalBreaksUsed + 1,
    lastBreakEndReason: ""
  });

  await saveState(nextState);
  await disableBlockingRules();
  await scheduleAlarms(nextState);
  await updateBadge(nextState);
  return toPublicState(nextState);
}

async function endBreak(reason = "manual") {
  const state = await getState();
  const nextState = normalizeState({
    ...state,
    breakActive: false,
    breakStartedAt: 0,
    breakUntil: 0,
    lastBreakEndedAt: Date.now(),
    lastBreakEndReason: reason
  });

  await saveState(nextState);
  await enableBlockingRules();
  await scheduleAlarms(nextState);
  await updateBadge(nextState);

  if (nextState.closeExistingTabs) {
    await redirectExistingYouTubeTabs();
  }

  return toPublicState(nextState);
}

async function updateSettings({ closeExistingTabs }) {
  const state = await getState();
  const nextState = normalizeState({
    ...state,
    closeExistingTabs:
      closeExistingTabs === undefined ? state.closeExistingTabs : Boolean(closeExistingTabs)
  });

  await saveState(nextState);
  await syncBlockState({ redirectTabs: false });
  return toPublicState(nextState);
}

async function syncBlockState({ redirectTabs = false } = {}) {
  const state = await getState();
  await scheduleAlarms(state);

  if (isBreakActive(state)) {
    await disableBlockingRules();
    await updateBadge(state);
    return toPublicState(state);
  }

  await enableBlockingRules();
  await updateBadge(state);

  if (redirectTabs || state.closeExistingTabs) {
    await redirectExistingYouTubeTabs();
  }

  return toPublicState(state);
}

async function maybeRedirectUpdatedTab(tabId, url) {
  if (!isYoutubeLikeUrl(url)) {
    return;
  }

  const state = await syncBlockState();

  if (!state.isBlocked) {
    return;
  }

  try {
    await chrome.tabs.update(tabId, { url: blockedPageUrl() });
  } catch {
    // Ignore tabs that cannot be updated.
  }
}

async function handleMessage(message) {
  switch (message?.type) {
    case "GET_STATE":
      return syncBlockState();
    case "START_BREAK":
      return startBreak();
    case "END_BREAK":
      return endBreak("manual");
    case "UPDATE_SETTINGS":
      return updateSettings(message.payload || {});
    case "OPEN_OPTIONS":
      await chrome.runtime.openOptionsPage();
      return syncBlockState();
    default:
      throw new Error("Unknown request.");
  }
}

chrome.runtime.onInstalled.addListener(() => {
  void syncBlockState({ redirectTabs: true });
});

chrome.runtime.onStartup.addListener(() => {
  void syncBlockState({ redirectTabs: true });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === BREAK_END_ALARM) {
    void endBreak("expired");
    return;
  }

  if (alarm.name === TICK_ALARM) {
    void syncBlockState({ redirectTabs: false });
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.url) {
    void maybeRedirectUpdatedTab(tabId, changeInfo.url);
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then((state) => sendResponse({ ok: true, state }))
    .catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));

  return true;
});

void syncBlockState({ redirectTabs: true });
