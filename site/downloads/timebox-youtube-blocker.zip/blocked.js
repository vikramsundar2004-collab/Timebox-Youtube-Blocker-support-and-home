const blockedStatus = document.querySelector("#blockedStatus");
const blockedCountdown = document.querySelector("#blockedCountdown");
const breakButton = document.querySelector("#breakButton");
const safePageButton = document.querySelector("#safePageButton");
const optionsButton = document.querySelector("#optionsButton");

let state = null;

function sendMessage(type, payload = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, payload }, (response) => {
      const runtimeError = chrome.runtime.lastError;

      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }

      if (!response?.ok) {
        reject(new Error(response?.error || "The extension did not respond."));
        return;
      }

      resolve(response.state);
    });
  });
}

function formatCountdown(endTime) {
  const remainingMs = Math.max(0, endTime - Date.now());
  const totalSeconds = Math.ceil(remainingMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function render() {
  const breakActive = state?.breakActive && state.breakUntil > Date.now();

  if (breakActive) {
    blockedStatus.textContent = "Break is active. Sending you back to YouTube...";
    blockedCountdown.textContent = formatCountdown(state.breakUntil);
    breakButton.disabled = true;
    window.location.replace("https://www.youtube.com/");
    return;
  }

  if (state?.dailyLimitReached) {
    blockedStatus.textContent = "Blocking protocol is active. You used all 3 breaks today.";
    blockedCountdown.textContent = "0";
    breakButton.disabled = true;
    return;
  }

  blockedStatus.textContent = "Use one 20-minute break to unlock YouTube.";
  blockedCountdown.textContent = String(state?.breaksRemaining ?? 3);
  breakButton.disabled = false;
}

async function refresh() {
  try {
    state = await sendMessage("GET_STATE");
    render();
  } catch (error) {
    blockedStatus.textContent = error.message;
  }
}

async function startBreak() {
  try {
    breakButton.disabled = true;
    state = await sendMessage("START_BREAK");
    render();
  } catch (error) {
    blockedStatus.textContent = error.message;
    breakButton.disabled = Boolean(state?.dailyLimitReached);
  }
}

breakButton.addEventListener("click", startBreak);

safePageButton.addEventListener("click", () => {
  window.location.href = "about:blank";
});

optionsButton.addEventListener("click", () => {
  void sendMessage("OPEN_OPTIONS");
});

setInterval(() => {
  render();

  if (state?.breakActive && state.breakUntil <= Date.now()) {
    void refresh();
  }
}, 1000);

void refresh();
