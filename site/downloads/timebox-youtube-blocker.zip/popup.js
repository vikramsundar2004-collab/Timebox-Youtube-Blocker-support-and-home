const blockedPanel = document.querySelector("#blockedPanel");
const breakPanel = document.querySelector("#breakPanel");
const statusText = document.querySelector("#statusText");
const breaksRemainingText = document.querySelector("#breaksRemainingText");
const breakButton = document.querySelector("#breakButton");
const endBreakButton = document.querySelector("#endBreakButton");
const countdownText = document.querySelector("#countdownText");
const endTimeText = document.querySelector("#endTimeText");
const usedText = document.querySelector("#usedText");
const limitText = document.querySelector("#limitText");
const messageText = document.querySelector("#messageText");
const optionsButton = document.querySelector("#optionsButton");

let currentState = null;
let countdownTimer = null;

function sendMessage(type, payload = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, payload }, (response) => {
      const runtimeError = chrome.runtime.lastError;

      if (runtimeError) {
        reject(new Error(runtimeError.message));
        return;
      }

      if (!response?.ok) {
        reject(new Error(response?.error || "The extension did not respond."));
        return;
      }

      resolve(response.state);
    });
  });
}

function setMessage(text = "") {
  messageText.textContent = text;
}

function formatCountdown(endTime) {
  const remainingMs = Math.max(0, endTime - Date.now());
  const totalSeconds = Math.ceil(remainingMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;

  return `${minutes}:${String(seconds).padStart(2, "0")}`;
}

function formatTime(time) {
  return new Date(time).toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit"
  });
}

function renderState(state) {
  currentState = state;
  const breakActive = state.breakActive && state.breakUntil > Date.now();

  blockedPanel.hidden = breakActive;
  breakPanel.hidden = !breakActive;

  breaksRemainingText.textContent = String(state.breaksRemaining);
  usedText.textContent = `${state.breaksUsed} of ${state.dailyBreakLimit} breaks used today.`;

  if (!breakActive) {
    clearInterval(countdownTimer);
    countdownTimer = null;
    statusText.textContent = state.dailyLimitReached
      ? "YouTube is blocked. No breaks left today."
      : "YouTube is blocked by default.";
    breakButton.disabled = state.dailyLimitReached;
    limitText.hidden = !state.dailyLimitReached;
    return;
  }

  statusText.textContent = "YouTube is unlocked for this break.";
  endTimeText.textContent = `Break ends at ${formatTime(state.breakUntil)}.`;

  function tick() {
    countdownText.textContent = formatCountdown(state.breakUntil);

    if (state.breakUntil <= Date.now()) {
      refreshState();
    }
  }

  tick();
  clearInterval(countdownTimer);
  countdownTimer = setInterval(tick, 1000);
}

async function refreshState() {
  try {
    const state = await sendMessage("GET_STATE");
    renderState(state);
  } catch (error) {
    setMessage(error.message);
  }
}

async function startBreak() {
  try {
    setMessage("");
    breakButton.disabled = true;
    const state = await sendMessage("START_BREAK");
    renderState(state);
  } catch (error) {
    setMessage(error.message);
  } finally {
    breakButton.disabled = Boolean(currentState?.dailyLimitReached);
  }
}

async function endBreak() {
  try {
    setMessage("");
    endBreakButton.disabled = true;
    const state = await sendMessage("END_BREAK");
    renderState(state);
  } catch (error) {
    setMessage(error.message);
  } finally {
    endBreakButton.disabled = false;
  }
}

breakButton.addEventListener("click", startBreak);
endBreakButton.addEventListener("click", endBreak);
optionsButton.addEventListener("click", () => {
  void sendMessage("OPEN_OPTIONS").catch((error) => setMessage(error.message));
});

void refreshState();
