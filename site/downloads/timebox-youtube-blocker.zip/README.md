# Timebox YouTube Blocker

A small Chrome/Edge extension that blocks YouTube by default and gives you three 20-minute breaks per day.

## What it blocks

- `youtube.com` and subdomains such as `www.youtube.com` and `m.youtube.com`
- `youtu.be` short links
- `youtube-nocookie.com` embeds
- direct `googlevideo.com` media requests

The blocker uses Manifest V3 dynamic `declarativeNetRequest` rules, so YouTube navigations are redirected before the page loads. When a break ends, any already-open YouTube tabs can be moved back to the blocked page.

There is also a small content-script fallback that redirects YouTube pages if a page gets past the browser-level rule.

## Install locally

1. Open Chrome or Edge.
2. Go to `chrome://extensions` or `edge://extensions`.
3. Turn on Developer mode.
4. Choose Load unpacked.
5. Select this folder: `C:\Users\vikra\OneDrive\Documents\New project 4`.
6. Pin the extension. YouTube is blocked automatically.
7. Click **Give me a break** when you want one 20-minute YouTube break.

## Features

- YouTube is blocked by default.
- **Give me a break** unlocks YouTube for 20 minutes.
- Breaks cannot be extended or stacked.
- You get 3 breaks per local day.
- After the third break, blocking protocol stays active until tomorrow.
- Break state persists in extension storage and is restored after browser restart.
- Options page for open-tab handling after breaks end.

## Limits

This blocks YouTube only in the browser profile where the extension is installed and enabled. Browser extensions cannot prevent you from disabling/removing the extension, using a different browser/profile, or using another device.

## Developer check

Run:

```powershell
npm run check
```

This validates the manifest and checks JavaScript syntax.

## Sales website

This repo also includes a small Stripe Checkout sales site.

Run it locally:

```powershell
copy .env.example .env
npm install
npm start
```

Then open:

```text
http://localhost:4242
```

Set these values in `.env` before taking real payments:

- `STRIPE_SECRET_KEY`: your Stripe secret key.
- `STRIPE_WEBHOOK_SECRET`: from `stripe listen --forward-to localhost:4242/api/webhook` locally, or from your production webhook endpoint.
- `PUBLIC_URL`: your deployed site URL.
- `CHROME_WEB_STORE_URL`: optional free Chrome Web Store listing URL.

The site charges $5 with Stripe Checkout, fulfills paid Checkout Sessions, creates 24-hour download links, and lets already-paid users recover access by email at `/access.html`.

Full Stripe setup checklist:

```text
docs\STRIPE_SETUP.md
```

Build a clean extension zip:

```powershell
npm run build:extension
```

Output:

```text
dist\timebox-youtube-blocker.zip
```

Chrome Web Store payments are deprecated. Publish the extension listing as free, then use this website as the paid access gate so customers do not pay twice.
